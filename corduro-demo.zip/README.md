# Corduro® — Demo Website

A premium marketing website built as a demonstration for Corduro Inc., a full-stack payment infrastructure company based in Dallas, Texas.

## Overview

This is a **static single-page site** (`index.html`) requiring zero build tools, zero dependencies, and zero configuration. Drop it anywhere and it works.

## Features

- McKinsey-style editorial design — Cormorant Garamond + DM Sans
- Navy / blue / white premium color system
- Fully responsive — optimized for mobile, tablet, and desktop
- Animated stats counter, interchange comparison, and routing canvas
- Real content from Corduro's company overview (executive team, regulatory tailwind, compliance, competitive advantage)
- GitHub Pages ready out of the box

## Sections

1. Hero — core value proposition
2. Network strip — STAR, NYCE, Accel, Pulse, SHAZAM, CU24, Fiserv
3. Stats — $4.7T volume, $30B+ savings opportunity, 25% cost reduction, 17B+ transactions
4. Platform — POS, Online, Mobile, Developer API
5. Technology — debit re-routing, interchange comparison ($0.39 vs $0.25), routing canvas
6. Regulatory Tailwind — Reg II, FTC/Mastercard, DOJ/Visa, Amazon/Walmart precedent
7. Leadership — Jim Aviles, Stephen Prince, Robert Ziegler, Nicholas Koustas
8. Compliance — Level 1 PCI DSS, TLS 1.2+, AES-256, E2EE, Tokenization
9. Competitive Advantage — Fiserv exclusivity, national coverage, BIN ownership
10. Pricing — monthly/yearly toggle with animated number transitions
11. Contact — inquiry form with volume selector

## Deployment

### GitHub Pages (recommended)

1. Push this repo to GitHub (see setup instructions below)
2. Go to **Settings → Pages**
3. Set source to `Deploy from a branch` → `main` → `/ (root)`
4. Your site will be live at `https://<your-username>.github.io/corduro-demo`

### Any static host

Upload `index.html` to Netlify, Vercel, Cloudflare Pages, or any web server. No build step required.

## Important

This is a **demonstration site only** — not the official Corduro website. All content is sourced from Corduro's company overview document and is presented here as a design example for the Corduro team.

---

*Built with HTML, CSS, and vanilla JavaScript. No frameworks, no build tools.*
